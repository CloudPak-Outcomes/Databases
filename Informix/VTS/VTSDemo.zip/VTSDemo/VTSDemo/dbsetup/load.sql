load from master.asc insert into master;
load from tracking.asc insert into tracking;
