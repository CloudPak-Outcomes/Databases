-- Execute following procedure to allow new line within ' '
--=============================================================

execute procedure ifx_allow_newline('t');

INSERT INTO CalendarPatterns values
(
      'min5', '{1 on,4 off },minute'
);
INSERT INTO CalendarTable
(
        c_name, c_calendar
)
values ('cal5min','startdate(2010-10-23 00:00:00.00000), pattstart(2010-10-23 00:00:00.00000), pattname(min5)');


create table master
(
    vehicle_number integer not null ,
    vehicle_model char(100),
    depo_address char(100),
    geofence ST_geometry,
    primary key (vehicle_number)  constraint vehicle_master_pk
);
 

--=============================================================
--Create row type for defining timeseries
--=============================================================
create row type vehicle_rt
(
 report_time datetime year to fraction(5),
 fuel decimal(7,2),
 latitude decimal(10,8),
 longitude decimal(10,8)
);


--=============================================================
--Create a table which will store real time information of vehicles
--=============================================================
create table vehicle_tracking_ts
(
vehicle_number integer not null,
vehicle_info timeseries(vehicle_rt),
PRIMARY KEY(vehicle_number) constraint vehicle_number_pk,
FOREIGN KEY(vehicle_number) REFERENCES master(vehicle_number)
 constraint units_provisioned_measure_fk1
)lock mode row;

create table fuel_exception
(
 vehicle_number integer not null
);
create table fence_exception
(
 vehicle_number integer not null,
 exp char(2)
);

execute procedure TSContainerCreate('tscont1','dbspace1','vehicle_rt',51200,51200);

execute procedure TSCreateVirtualTab('tracking','vehicle_tracking_ts', 
'origin(2010-10-23 01:00:00.00000), calendar(cal5min), container(tscont1),threshold(20), regular');
