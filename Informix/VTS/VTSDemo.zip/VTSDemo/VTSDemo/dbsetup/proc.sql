create function fuel_cons(veh_no integer)
returning decimal(7,2);
DEFINE qry_str char(300);
DEFINE cur_fuel decimal(7,2);
DEFINE prev_fuel decimal(7,2);
DEFINE total_fuel decimal(7,2);

LET total_fuel = 0.00;
LET prev_fuel = 0.00;

PREPARE str from "select fuel from tracking where vehicle_number="||veh_no||"";
DECLARE simp_cur1 CURSOR for str;
OPEN simp_cur1;
  WHILE(SQLCODE == 0)
    FETCH simp_cur1 into cur_fuel;
    IF SQLCODE == 100
    THEN
       EXIT WHILE;
    END IF;
    if  cur_fuel < prev_fuel
    then
       LET total_fuel = total_fuel + prev_fuel - cur_fuel;
    end if;
    LET prev_fuel = cur_fuel;
  END WHILE;
CLOSE simp_cur1;
FREE simp_cur1;
FREE str;

return total_fuel;

end function;

drop function tot_dist(integer);
create function tot_dist(veh_no integer)
returning decimal(7,2);
DEFINE qry_str char(300);
DEFINE cur_loc lvarchar(45);
DEFINE prev_loc lvarchar(45);
DEFINE total_dist decimal(7,2);


LET total_dist = 0.00;
LET prev_loc = "NULL";

--PREPARE str from "select '"4 POINT ('"||longitude||'" '"||latitude||'")'"::lvarchar(45) from tracking vehicle_number="||veh_no||"";
PREPARE str from  "select '4 POINT ('||longitude||' '||latitude||')'::lvarchar(45) from tracking where vehicle_number="||veh_no||";";

DECLARE simp_cur1 CURSOR for str;
OPEN simp_cur1;
  WHILE(SQLCODE == 0)
    FETCH simp_cur1 into cur_loc;
    IF SQLCODE == 100
    THEN
       EXIT WHILE;
    END IF;
    if  prev_loc != "NULL"
    then
       LET total_dist = total_dist + st_distance(prev_loc,cur_loc);
    end if;
    LET prev_loc = cur_loc;
  END WHILE;
CLOSE simp_cur1;
FREE simp_cur1;
FREE str;
LET total_dist = total_dist * 1000;
return total_dist;

end function;
