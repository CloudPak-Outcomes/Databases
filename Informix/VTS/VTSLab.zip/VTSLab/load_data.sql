LOAD FROM master.asc INSERT INTO master;
LOAD FROM tracking.asc INSERT INTO tracking;
