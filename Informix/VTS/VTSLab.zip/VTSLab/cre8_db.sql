DROP DATABASE if exists vts;
CREATE DATABASE vts IN data_space_1 with log;

grant dba to "informix";
grant connect to "public";
