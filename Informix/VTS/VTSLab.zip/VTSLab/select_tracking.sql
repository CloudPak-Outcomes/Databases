SELECT * FROM tracking
WHERE  vehicle_number = 1231;
