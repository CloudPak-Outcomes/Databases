SELECT * FROM vehicle_tracking_ts
WHERE  vehicle_number = 1231;
