SELECT vehicle_number, 
       Apply('$0.fuel - tsprevious($0.fuel), $0.latitude, $0.longitude',
             vehicle_info)::timeseries(vehicle_rt) info
FROM   vehicle_tracking_ts
INTO TEMP xxx;

SELECT a.vehicle_number, a.report_time, a.fuel_delta, a.latitude, a.longitude
FROM TABLE(transpose('select * from xxx',
           NULL::row(vehicle_number INTEGER,
                     report_time DATETIME YEAR TO FRACTION(5),
                     fuel_delta DECIMAL(7,2),
                     latitude DECIMAL(10,8),
                     longitude DECIMAL(10,8) )
                    )
          ) as tab(a)
where a.fuel_delta < -0.75; -- possible exceptions

