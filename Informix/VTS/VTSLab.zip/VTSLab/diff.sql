SELECT 1236 as vehicle_number, a.report_time, a.fuel, a.latitude, a.longitude
FROM table(transpose((
  SELECT Apply('$0.fuel - tsprevious($0.fuel), $0.latitude, $0.longitude',
               vehicle_info)::timeseries(vehicle_rt)
  FROM   vehicle_tracking_ts
  WHERE  vehicle_number = 1236
)) ) as tab(a)
WHERE a.fuel < -0.75
;

SELECT vehicle_number, 
       Apply('$0.fuel - tsprevious($0.fuel), $0.latitude, $0.longitude',
             vehicle_info)::timeseries(vehicle_rt)
FROM   vehicle_tracking_ts;
