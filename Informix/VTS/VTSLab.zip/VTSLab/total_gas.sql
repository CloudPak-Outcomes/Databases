SELECT vehicle_number, depo_address,
       fuel_cons(vehicle_number) fuel_cons,
       fuel_count(vehicle_number) cnt_readings,
       (fuel_cons(vehicle_number) /
        fuel_count(vehicle_number))::decimal(5,2) ratio
FROM   master
WHERE  fuel_count(vehicle_number) > 0;
