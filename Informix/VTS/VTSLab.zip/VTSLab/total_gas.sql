SELECT vehicle_number, vehicle_model, depo_address,
       fuel_cons(vehicle_number) fuel_cons
FROM   master;
