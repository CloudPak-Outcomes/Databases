CREATE TABLE master
(
    vehicle_number INTEGER NOT NULL ,
    vehicle_model CHAR(100),
    depo_address CHAR(100),
    geofence ST_geometry,
    PRIMARY KEY (vehicle_number) CONSTRAINT vehicle_master_pk
);

