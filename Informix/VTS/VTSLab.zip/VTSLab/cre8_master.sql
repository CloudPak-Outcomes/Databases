CREATE TABLE master
(
    vehicle_number INTEGER NOT NULL ,
    vehicle_model VARCHAR(10),
    depo_address VARCHAR(30),
    geofence ST_geometry,
    PRIMARY KEY (vehicle_number) CONSTRAINT vehicle_master_pk
);

