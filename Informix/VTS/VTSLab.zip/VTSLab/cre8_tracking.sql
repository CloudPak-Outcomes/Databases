--=============================================================
-- Create a calendar pattern at 5 minute interval and a calendar
--=============================================================
INSERT INTO CalendarPatterns
VALUES ( 'min5', '{1 on,4 off },minute');

INSERT INTO CalendarTable(c_name, c_calendar)
VALUES('cal5min',
       'startdate(2021-10-25 00:00:00.00000),' ||
       'pattstart(2021-10-25 00:00:00.00000), pattname(min5)');
--=============================================================
-- Create a virtual table to make a time series look like
-- a regular relational table
--=============================================================
EXECUTE PROCEDURE
     TSContainerCreate('tscont1','data_space_1','vehicle_rt',51200,51200);

EXECUTE PROCEDURE
     TSCreateVirtualTab('tracking','vehicle_tracking_ts', 
'origin(2021-10-25 01:00:00.00000), calendar(cal5min), container(tscont1),threshold(20), regular');
