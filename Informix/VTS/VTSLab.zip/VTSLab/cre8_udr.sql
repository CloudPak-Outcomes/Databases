-- Return the fuel consumption for a vehicle
-- It is done by day since it could be refueled
-- This uses the virtual table instead of the TS directly.
CREATE FUNCTION fuel_cons(p_vehicle_number INT)
  RETURNING INT;
  DEFINE total decimal(8,2);
  SELECT SUM(fuel_cons) INTO total
  FROM (
      SELECT DATE(report_time), MAX(fuel) - MIN(fuel) as fuel_cons
      FROM tracking
      WHERE vehicle_number = p_vehicle_number
      GROUP BY 1
  );
  RETURN total;
END FUNCTION;
