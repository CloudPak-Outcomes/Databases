SELECT m.vehicle_number, cur_day,
        fuel_cons, cnt_readings,
        (fuel_cons / cnt_readings)::decimal(5,2) ratio
FROM   master m,
       (SELECT vehicle_number, report_time::datetime year to day cur_day,
               (MAX(fuel) - MIN(fuel))::decimal(5,2) fuel_cons,
               COUNT(fuel) cnt_readings
        FROM   tracking
        GROUP BY vehicle_number, cur_day
       ) as t
WHERE m.vehicle_number = t.vehicle_number
AND   cnt_readings > 0
ORDER BY vehicle_number;
