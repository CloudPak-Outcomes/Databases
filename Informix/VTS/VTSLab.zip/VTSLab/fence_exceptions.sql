SELECT a.vehicle_number, report_time, fuel, latitude, longitude
FROM   tracking a,master b
WHERE  a.vehicle_number=b.vehicle_number
AND    st_within("4 POINT (" || longitude || " " || latitude || ")",
       st_buffer(geofence,0.0001)) = 'f'
AND    report_time BETWEEN "2021-10-26 00:00:00.00000"
                   AND     "2021-10-27 00:00:00.00000";

