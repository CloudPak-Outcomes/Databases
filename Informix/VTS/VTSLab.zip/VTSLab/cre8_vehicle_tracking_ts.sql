--=============================================================
-- Create ROW TYPE for defining timeseries
--=============================================================
CREATE ROW TYPE vehicle_rt
(
 report_time DATETIME YEAR TO FRACTION(5),
 fuel DECIMAL(7,2),
 latitude DECIMAL(10,8),
 longitude DECIMAL(10,8)
);

--=============================================================
-- Create a table which will store real time information of vehicles
--=============================================================
CREATE TABLE vehicle_tracking_ts
(
  vehicle_number INTEGER NOT NULL,
  vehicle_info timeseries(vehicle_rt),
  PRIMARY KEY(vehicle_number) CONSTRAINT vehicle_number_pk,
  FOREIGN KEY(vehicle_number) REFERENCES master(vehicle_number)
           CONSTRAINT units_provisioned_measure_fk1
)LOCK MODE ROW;

